import React from 'react';
import styles from './App.module.css';
import FetchPokemon from './components/FetchPokemon';

function App() {
  return <FetchPokemon />;
}

export default App;
